import dashboard from "./clinic-dashboard.html?raw";
export const dynamic = "force-dynamic";
export function GET() { return new Response(dashboard, { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store", "X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "same-origin" } }); }
