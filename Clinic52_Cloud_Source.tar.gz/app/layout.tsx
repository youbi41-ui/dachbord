import type { Metadata } from "next";
export const metadata: Metadata = { title: "عيادة سكن 52", description: "منصة العيادة الطبية في سكن 52" };
export default function RootLayout({ children }: { children: React.ReactNode }) { return <html lang="ar" dir="rtl"><body>{children}</body></html>; }
