import { handleClinicRequest } from "../../../lib/clinic/api";
export const dynamic = "force-dynamic";
export const GET = handleClinicRequest;
export const POST = handleClinicRequest;
