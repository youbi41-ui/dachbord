CREATE TABLE `clinic_account_audit` (
	`id` text PRIMARY KEY NOT NULL,
	`at` text NOT NULL,
	`actor` text NOT NULL,
	`op` text NOT NULL,
	`username` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `clinic_attempts` (
	`key` text PRIMARY KEY NOT NULL,
	`count` integer NOT NULL,
	`until` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE `clinic_meta` (
	`id` integer PRIMARY KEY NOT NULL,
	`revision` integer NOT NULL,
	`as_of` text NOT NULL,
	`excel_revision` integer,
	`excel_error` text
);
--> statement-breakpoint
CREATE TABLE `clinic_records` (
	`kind` text NOT NULL,
	`record_id` text NOT NULL,
	`body` text NOT NULL,
	PRIMARY KEY(`kind`, `record_id`)
);
--> statement-breakpoint
CREATE TABLE `clinic_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`username` text NOT NULL,
	`csrf` text NOT NULL,
	`expires` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `clinic_sessions_username` ON `clinic_sessions` (`username`);--> statement-breakpoint
CREATE TABLE `clinic_users` (
	`username` text PRIMARY KEY NOT NULL,
	`role` text NOT NULL,
	`slot` integer NOT NULL,
	`salt` text NOT NULL,
	`password_hash` text NOT NULL,
	`created_at` text NOT NULL,
	CONSTRAINT "clinic_role_slot" CHECK(("clinic_users"."role" = 'admin' AND "clinic_users"."slot" = 0) OR ("clinic_users"."role" = 'clinic' AND "clinic_users"."slot" BETWEEN 1 AND 5))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `clinic_users_slot_unique` ON `clinic_users` (`slot`);