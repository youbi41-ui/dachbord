import { env } from 'cloudflare:workers';
import Model from './model.mjs';
import Excel from './excel.mjs';

type Row = Record<string, any>;
const enc = new TextEncoder();
const kinds = ['workers','visits','prescriptions','dispensing','services','referrals','stocks','medicalStaff','attendance','issues','audit'];
class ApiError extends Error { constructor(public status:number, message:string){super(message);} }
function db(){ if(!env.DB) throw new ApiError(503,'خدمة حفظ البيانات غير متاحة حاليًا'); return env.DB; }
function json(data:unknown,status=200,cookie?:string){const h:Record<string,string>={'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','X-Frame-Options':'DENY'};if(cookie)h['Set-Cookie']=cookie;return new Response(JSON.stringify(data),{status,headers:h});}
function same(a:string,b:string){let result=a.length^b.length;for(let i=0;i<Math.max(a.length,b.length);i++)result|=(a.charCodeAt(i)||0)^(b.charCodeAt(i)||0);return result===0;}
function hex(bytes:ArrayBuffer|Uint8Array){return Array.from(new Uint8Array(bytes instanceof Uint8Array?bytes.buffer:bytes)).map(x=>x.toString(16).padStart(2,'0')).join('');}
function token(){return hex(crypto.getRandomValues(new Uint8Array(32)));}
async function sha(s:string){return hex(await crypto.subtle.digest('SHA-256',enc.encode(s)));}
async function passwordHash(password:string,salt:string){const key=await crypto.subtle.importKey('raw',enc.encode(password),'PBKDF2',false,['deriveBits']);return hex(await crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:enc.encode(salt),iterations:100000},key,256));}
function name(value:unknown){if(typeof value!=='string'||!/[a-z]/i.test(value)||!(/^[A-Za-z0-9._-]{3,40}$/).test(value))throw new ApiError(400,'اسم المستخدم: 3 إلى 40 حرفًا إنجليزيًا أو رقمًا أو . _ -');return value.toLowerCase();}
function password(value:unknown){if(typeof value!=='string'||value.length<12||value.length>200)throw new ApiError(400,'كلمة المرور يجب أن تكون بين 12 و200 حرف');return value;}
function cookie(request:Request,value:string,maxAge=28800){return 'clinic52='+value+'; Path=/; HttpOnly; SameSite=Strict; Max-Age='+maxAge+(new URL(request.url).protocol==='https:'?'; Secure':'');}
function cookieToken(request:Request){return request.headers.get('Cookie')?.split(';').map(x=>x.trim()).find(x=>x.startsWith('clinic52='))?.slice(9)||'';}
async function session(request:Request){const t=cookieToken(request);if(!/^[a-f0-9]{64}$/.test(t))return null;return db().prepare('SELECT s.*,u.role FROM clinic_sessions s JOIN clinic_users u ON u.username=s.username WHERE token_hash=? AND expires>?').bind(await sha(t),Date.now()).first<Row>();}
async function needSession(request:Request,admin=false){const s=await session(request);if(!s)throw new ApiError(401,'سجل الدخول أولًا');if(admin&&s.role!=='admin')throw new ApiError(403,'إدارة الحسابات لمسؤول النظام فقط');return s;}
async function newSession(request:Request,username:string,role:string){const t=token(),csrf=token();await db().batch([db().prepare('DELETE FROM clinic_sessions WHERE expires<?').bind(Date.now()),db().prepare('INSERT INTO clinic_sessions(token_hash,username,csrf,expires) VALUES(?,?,?,?)').bind(await sha(t),username,csrf,Date.now()+28800000)]);return json({user:{name:username,role},csrf},200,cookie(request,t));}
async function hasAdmin(){return !!await db().prepare("SELECT username FROM clinic_users WHERE role='admin' LIMIT 1").first();}
async function throttle(request:Request,username:string,scope='login'){
 const ip=request.headers.get('cf-connecting-ip')||'unknown',now=Date.now();
 const keys=await Promise.all([sha(scope+'|ip|'+ip),sha(scope+'|user|'+username.toLowerCase())]);
 const results=await db().batch(keys.flatMap(k=>[db().prepare('INSERT INTO clinic_attempts(key,count,until) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=CASE WHEN until>? THEN count+1 ELSE 1 END,until=CASE WHEN until>? THEN until ELSE excluded.until END').bind(k,now+900000,now,now),db().prepare('SELECT count FROM clinic_attempts WHERE key=?').bind(k)]));
 if(results.some((r,i)=>i%2===1&&(r.results?.[0] as Row)?.count>8))throw new ApiError(429,'محاولات كثيرة؛ حاول بعد 15 دقيقة');return keys;
}
async function clearAttempts(keys:string[]){await db().batch(keys.map(k=>db().prepare('DELETE FROM clinic_attempts WHERE key=?').bind(k)));}
function audit(actor:string,op:string,username:string){return db().prepare('INSERT INTO clinic_account_audit(id,at,actor,op,username) VALUES(?,?,?,?,?)').bind(crypto.randomUUID(),Model.now(),actor,op,username);}
async function readData(){
 const results=await db().batch([db().prepare('SELECT * FROM clinic_meta WHERE id=1'),db().prepare('SELECT kind,body FROM clinic_records ORDER BY kind,record_id')]);
 const meta=results[0].results?.[0] as Row|undefined;if(!meta)throw new ApiError(503,'يرجى إكمال إعداد حساب مسؤول النظام أولًا');
 const d:Row=Model.empty();d.synthetic=false;d.detailSynthetic=false;d.revision=meta.revision;d.asOf=meta.as_of;
 for(const record of results[1].results as Row[])if(kinds.includes(record.kind))d[record.kind].push(JSON.parse(record.body));
 d.municipalities=[...new Set(d.visits.map((v:Row)=>v.municipality).filter(Boolean))];Model.recompute(d);return {data:d,meta};
}
function excelStatus(meta:Row){return {ok:meta.excel_revision===meta.revision,revision:meta.excel_revision,file:'Clinic52_Data.xlsx',error:meta.excel_revision===meta.revision?undefined:(meta.excel_error||'نسخة Excel بانتظار التحديث')};}
async function syncExcel(d:Row){
 const key='excel/Clinic52_Data-r'+d.revision+'.xlsx';
 try{
  if(!env.BUCKET)throw Error('unavailable');
  const blob=Excel.create(d);await env.BUCKET.put(key,await blob.arrayBuffer(),{httpMetadata:{contentType:'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}});
  const results=await db().batch([db().prepare('SELECT excel_revision FROM clinic_meta WHERE id=1'),db().prepare('UPDATE clinic_meta SET excel_revision=?,excel_error=NULL WHERE id=1 AND revision=?').bind(d.revision,d.revision)]);
  const previous=(results[0].results?.[0] as Row)?.excel_revision;
  if(results[1].meta.changes){if(previous!==null&&previous!==undefined&&previous!==d.revision)await env.BUCKET.delete('excel/Clinic52_Data-r'+previous+'.xlsx');}
  else{const m=await db().prepare('SELECT excel_revision FROM clinic_meta WHERE id=1').first<Row>();if(m?.excel_revision!==d.revision)await env.BUCKET.delete(key);}
 }catch{
  await db().prepare('UPDATE clinic_meta SET excel_error=? WHERE id=1 AND revision=?').bind('تم حفظ السجلات؛ تعذر تحديث Excel. اضغط إعادة حفظ Excel للمحاولة.',d.revision).run();
 }
 const meta=await db().prepare('SELECT * FROM clinic_meta WHERE id=1').first<Row>();return excelStatus(meta!);
}
async function command(s:Row,b:Row){
 if(s.role!=='clinic')throw new ApiError(403,'هذا الحساب للمتابعة وإدارة الحسابات فقط');
 const {data:before}=await readData();if(!Number.isInteger(b.revision)||b.revision!==before.revision)throw new ApiError(409,'تغيرت البيانات بواسطة مستخدم آخر. راجع السجل ثم أعد الحفظ');
 if(!b.payload||typeof b.payload!=='object'||Array.isArray(b.payload))throw new ApiError(400,'بيانات العملية غير صحيحة');
 let change;try{change=Model.apply(before,b.op,b.payload,s.username);}catch(e){throw new ApiError(400,e instanceof Error?e.message:'بيانات العملية غير صحيحة');}
 const d=change.data,statements=[];
 for(const kind of kinds){const old=new Map(before[kind].map((r:Row)=>[r.id,JSON.stringify(r)]));for(const row of d[kind]){const body=JSON.stringify(row);if(old.get(row.id)!==body)statements.push(db().prepare('INSERT INTO clinic_records(kind,record_id,body) SELECT ?,?,? WHERE (SELECT revision FROM clinic_meta WHERE id=1)=? ON CONFLICT(kind,record_id) DO UPDATE SET body=excluded.body').bind(kind,row.id,body,b.revision));}}
 statements.push(db().prepare('UPDATE clinic_meta SET revision=?,as_of=?,excel_error=NULL WHERE id=1 AND revision=?').bind(d.revision,d.asOf,b.revision));
 const results=await db().batch(statements);if(!results.at(-1)?.meta.changes)throw new ApiError(409,'تغيرت البيانات بواسطة مستخدم آخر. حدّث السجل وأعد الحفظ');
 return json({data:d,id:change.id,excel:await syncExcel(d)});
}
async function get(request:Request,path:string){
 if(path==='/api/session'){const s=await session(request);return json({clinic52:true,user:s?{name:s.username,role:s.role}:null,csrf:s?.csrf||null,setupRequired:!await hasAdmin()});}
 const s=await needSession(request,path==='/api/users');
 if(path==='/api/users'){const users=await db().prepare("SELECT username FROM clinic_users WHERE role='clinic' ORDER BY username").all();return json({users:users.results,limit:5});}
 if(path==='/api/data'){const {data,meta}=await readData();return json({data,excel:excelStatus(meta)});}
 if(path==='/api/excel'){
  const {data,meta}=await readData();const worker=new URL(request.url).searchParams.get('worker');if(worker&&!data.workers.some((w:Row)=>w.id===worker))throw new ApiError(404,'ملف العامل غير موجود');
  let bytes:ArrayBuffer|ReadableStream|null=null;if(!worker&&meta.excel_revision===meta.revision&&env.BUCKET){const obj=await env.BUCKET.get('excel/Clinic52_Data-r'+meta.revision+'.xlsx');if(obj)bytes=obj.body;}
  if(!bytes)bytes=await Excel.create(data,worker||undefined).arrayBuffer();
  return new Response(bytes,{headers:{'Content-Type':'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','Content-Disposition':'attachment; filename="'+(worker?'Worker_File.xlsx':'Clinic52_Data.xlsx')+'"','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
 }
 throw new ApiError(404,'مسار غير موجود');
}
async function post(request:Request,path:string,b:Row){
 if(path==='/api/setup'){
  await throttle(request,'setup','setup');
  if(await hasAdmin())throw new ApiError(409,'تم إعداد حساب مسؤول النظام مسبقًا');
  if(!env.CLINIC_SETUP_TOKEN)throw new ApiError(503,'إعداد مسؤول النظام غير متاح حاليًا');
  if(typeof b.code!=='string'||!same(await sha(b.code),await sha(env.CLINIC_SETUP_TOKEN)))throw new ApiError(403,'رمز التهيئة غير صحيح');
  const username=name(b.username),pass=password(b.password),salt=token(),hash=await passwordHash(pass,salt),at=Model.now();
  const results=await db().batch([db().prepare('INSERT OR IGNORE INTO clinic_meta(id,revision,as_of) VALUES(1,0,?)').bind(at),db().prepare("INSERT INTO clinic_users(username,role,slot,salt,password_hash,created_at) SELECT ?,'admin',0,?,?,? WHERE NOT EXISTS(SELECT 1 FROM clinic_users WHERE role='admin')").bind(username,salt,hash,at),audit(username,'setup',username)]);
  if(!results[1].meta.changes)throw new ApiError(409,'تم إعداد مسؤول النظام مسبقًا');
  await syncExcel((await readData()).data);return newSession(request,username,'admin');
 }
 if(path==='/api/login'){
  const input=typeof b.username==='string'?b.username.slice(0,40).toLowerCase():'',keys=await throttle(request,input);
  if(typeof b.password!=='string'||b.password.length>200)throw new ApiError(401,'اسم المستخدم أو كلمة المرور غير صحيحة');
  const user=await db().prepare('SELECT * FROM clinic_users WHERE username=?').bind(input).first<Row>();
  const hash=await passwordHash(b.password,user?.salt||'0'.repeat(64));if(!user||!same(hash,user.password_hash))throw new ApiError(401,'اسم المستخدم أو كلمة المرور غير صحيحة');
  await clearAttempts(keys);return newSession(request,user.username,user.role);
 }
 const s=await needSession(request,path.startsWith('/api/users'));
 if(!same(request.headers.get('X-CSRF-Token')||'',s.csrf))throw new ApiError(403,'جلسة الطلب غير صحيحة؛ أعد تسجيل الدخول');
 if(path==='/api/logout'){await db().prepare('DELETE FROM clinic_sessions WHERE token_hash=?').bind(s.token_hash).run();return json({ok:true},200,cookie(request,'',0));}
 if(path==='/api/command')return command(s,b);
 if(path==='/api/excel/save')return json({excel:await syncExcel((await readData()).data)});
 if(path==='/api/users/save'){
  const username=name(b.username),pass=password(b.password),salt=token(),hash=await passwordHash(pass,salt);
  const existing=await db().prepare('SELECT role FROM clinic_users WHERE username=?').bind(username).first<Row>();
  if(existing&&existing.role!=='clinic')throw new ApiError(400,'اسم المستخدم محجوز لمسؤول النظام');
  if(existing){await db().batch([db().prepare("UPDATE clinic_users SET salt=?,password_hash=? WHERE username=? AND role='clinic'").bind(salt,hash,username),db().prepare('DELETE FROM clinic_sessions WHERE username=?').bind(username),audit(s.username,'reset_password',username)]);}
  else{
   const result=await db().prepare("INSERT INTO clinic_users(username,role,slot,salt,password_hash,created_at) SELECT ?,'clinic',s.slot,?,?,? FROM (SELECT 1 slot UNION ALL SELECT 2 UNION ALL SELECT 3 UNION ALL SELECT 4 UNION ALL SELECT 5) s WHERE NOT EXISTS(SELECT 1 FROM clinic_users u WHERE u.slot=s.slot) ORDER BY s.slot LIMIT 1").bind(username,salt,hash,Model.now()).run();
   if(!result.meta.changes)throw new ApiError(400,'تم بلوغ الحد الأقصى: خمسة حسابات للعيادة');await audit(s.username,'create_user',username).run();
  }
  return json({ok:true});
 }
 if(path==='/api/users/disable'){
  const username=name(b.username),target=await db().prepare("SELECT username FROM clinic_users WHERE username=? AND role='clinic'").bind(username).first();if(!target)throw new ApiError(404,'حساب العيادة غير موجود');
  await db().batch([db().prepare('DELETE FROM clinic_sessions WHERE username=?').bind(username),db().prepare("DELETE FROM clinic_users WHERE username=? AND role='clinic'").bind(username),audit(s.username,'disable_user',username)]);return json({ok:true});
 }
 if(path==='/api/password'){
  const keys=await throttle(request,s.username,'password'),user=await db().prepare('SELECT * FROM clinic_users WHERE username=?').bind(s.username).first<Row>();
  if(typeof b.currentPassword!=='string'||b.currentPassword.length>200||!user||!same(await passwordHash(b.currentPassword,user.salt),user.password_hash))throw new ApiError(400,'كلمة المرور الحالية غير صحيحة');
  const pass=password(b.password),salt=token(),hash=await passwordHash(pass,salt);await db().batch([db().prepare('UPDATE clinic_users SET salt=?,password_hash=? WHERE username=?').bind(salt,hash,s.username),db().prepare('DELETE FROM clinic_sessions WHERE username=?').bind(s.username),audit(s.username,'change_own_password',s.username)]);await clearAttempts(keys);return newSession(request,s.username,s.role);
 }
 throw new ApiError(404,'مسار غير موجود');
}
export async function handleClinicRequest(request:Request){
 try{
  const url=new URL(request.url),path=url.pathname;
  if(request.method==='GET')return await get(request,path);
  if(request.method!=='POST')throw new ApiError(405,'طريقة طلب غير مسموحة');
  const origin=request.headers.get('Origin');if(origin&&origin!==url.origin)throw new ApiError(403,'مصدر الطلب غير مسموح');
  if(!request.headers.get('Content-Type')?.toLowerCase().startsWith('application/json'))throw new ApiError(415,'نوع الطلب غير صحيح');
  if(Number(request.headers.get('Content-Length'))>100000)throw new ApiError(413,'حجم الطلب أكبر من الحد المسموح');
  const raw=await request.text();if(enc.encode(raw).length>100000)throw new ApiError(413,'حجم الطلب أكبر من الحد المسموح');
  let body;try{body=JSON.parse(raw);}catch{throw new ApiError(400,'طلب غير صحيح');}if(!body||typeof body!=='object'||Array.isArray(body))throw new ApiError(400,'طلب غير صحيح');
  return await post(request,path,body);
 }catch(error){if(error instanceof ApiError)return json({error:error.message},error.status);console.error('Clinic API operation failed',error instanceof Error?error.name:'Unknown');return json({error:'تعذر تنفيذ الطلب؛ حاول مرة أخرى أو تواصل مع مسؤول النظام'},500);}
}
